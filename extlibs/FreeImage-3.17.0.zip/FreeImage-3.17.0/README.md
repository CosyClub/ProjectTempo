# FreeImage 

This repository is a fork of the FreeImage project that supports building via CMake. Please see the [original project](https://sourceforge.net/projects/freeimage/) if you want the unmodified codebase.

## Building 

Make sure CMake is installed, and run the following commands:

```
$ mkdir build-FreeImage 
$ cmake /path/to/FreeImage 
$ make 
```
