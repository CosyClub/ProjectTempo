Conan package for the [GLM](https://github.com/g-truc/glm) library

The package is hosted on [bintray](https://bintray.com/dimi309/conan-packages/glm%3Ag-truc). Until it gets accepted to the conan-center repository, in order to use it, you need to add this repository as a remote to your conan installation:

	conan remote add bintraydimi309 https://api.bintray.com/conan/dimi309/conan-packages

It works on Windows (Visual Studio or MinGW), MacOS/OSX and Linux.

